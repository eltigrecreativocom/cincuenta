# Modal popup - ink transition effect - WIP

A Pen created on CodePen.

Original URL: [https://codepen.io/2kool2/pen/WjZLdp](https://codepen.io/2kool2/pen/WjZLdp).

An ink bleed transition effect, powered by CSS animations.
Furtherance of https://codyhouse.co/gem/ink-transition-effect.